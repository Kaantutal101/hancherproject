ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent("west-uzum:uzum")
AddEventHandler("west-uzum:uzum", function()
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.canCarryItem("uzum", 1) then
        xPlayer.addInventoryItem("uzum", 1)
    else
        TriggerClientEvent('esx:showNotification', source, 'Üzerinde Yeterli Alan Yok')
    end
end)

RegisterNetEvent("west-uzum:uzumsat")
AddEventHandler("west-uzum:uzumsat", function()
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.getQuantity("uzum") >= 10 then
        xPlayer.removeInventoryItem("uzum", 10)
        Citizen.Wait(500)
        xPlayer.addMoney(5000)
    else
        TriggerClientEvent('esx:showNotification', source, 'Üzerinde En Az 10 Tane Üzüm Olması Gerek!')
    end
end)

RegisterNetEvent("west-uzum:sarapyap")
AddEventHandler("west-uzum:sarapyap", function()
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.removeInventoryItem("uzum", 10) then
        Citizen.Wait(500)
        xPlayer.addInventoryItem("sarap", 5)
    end
end)

RegisterNetEvent("west-uzum:sarapsat")
AddEventHandler("west-uzum:sarapsat", function()
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.removeInventoryItem("sarap", 5) then
        Citizen.Wait(500)
        xPlayer.addMoney(7500)
    end
end)


ESX.RegisterServerCallback("west-uzum:uzumkontrol", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.getQuantity("uzum") >= 20 then
        cb(true)
    else
        cb(false) 
    end
end)

ESX.RegisterServerCallback("west-uzum:sarapkontrol", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.getQuantity("sarap") >= 10 then
        cb(true)
    else
        cb(false) 
    end
end)

AddEventHandler('onResourceStart', function(resource)
	if resource == GetCurrentResourceName() then
		Citizen.Wait(5000)
		print('[^2west-illegal^0] - Started!')
	end
end)

