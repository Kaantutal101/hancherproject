# Bu Script Hancher Tarafından Yapılmıştır Satışı Yasaktır
# Dataya Manuel Olarak uzum Ve sarp İtemi Eklemelisiniz